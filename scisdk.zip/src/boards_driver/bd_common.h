#include <stdint.h>
#include <vector>
typedef struct {
    uint32_t    address;
    uint32_t    value;
} bd_reg;

